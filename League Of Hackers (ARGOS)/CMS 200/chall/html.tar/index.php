<?php
session_start();
require_once("db.php");
require_once("func.php");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<title><?php echo $title; ?></title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap.min.css">
<link href="css.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Main</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
		<?php
			if(!isset($_SESSION['id'])) {
        		echo '<li><a href="login.php">LOGIN</a></li>';
				echo '<li><a href="register.php">REGISTER</a></li>';
			} else {
				echo '<li><a href="logout.php">LOGOUT</a></li>';
				echo '<li><a href="fileviewer.php">FILE</a></li>';
			}
		?>
        <li><a href="board.php">BOARD</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- First Container -->
<div class="container-fluid bg-1" id="index_container">
	<div class="jumbotron">
		<h1>Intranet</h1>
		<p>Under Construction...</p>
	</div>
</div>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
  <p>Copyright (C) 2016 Hide All Rights Reserved</p>
</footer>

</body>
</html>
