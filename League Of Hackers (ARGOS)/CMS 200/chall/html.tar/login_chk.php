<?php
session_start();
if(!isset($_SESSION['id'])) {
	echo "<script>alert('Please login first')</script>";
	echo "<script>location.href='./login.php';</script>";
}
?>
