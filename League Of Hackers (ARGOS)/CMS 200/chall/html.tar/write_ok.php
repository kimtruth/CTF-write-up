<?php
require_once("db.php");
require_once("login_chk.php");

$subject = $_POST['subject'];
$content = $_POST['content'];
if(!empty($subject) && !empty($content)) {
	$stmt = $conn->prepare("insert into board(subject, content, writer)
					values(?,?,?)");
	$stmt->execute([$subject, $content, $_SESSION['id']]);
	echo "<script>location.href='board.php';</script>";
} else {
	echo "<script>alert('Subject or Content is empty');</script>";
	echo "<script>history.back();</script>";
}
?>
