<?php
$dir = $_GET['n'];
$dh = opendir($dir);
$txt = array();
while($file=readdir($dh)) {
	echo "Searching...<br>";
	if(substr($file,-3)=="txt") {
		$txt[] = $file;
	}
}
@closedir($dh);
echo "<br><b>[TXT list]</b><br>";
foreach($txt as $data) {
	echo $data."<br>";
}
?>
