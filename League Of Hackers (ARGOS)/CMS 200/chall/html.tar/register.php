<?php
require_once("db2.php");
require_once("func.php");
$id = addslashes($_GET['id']);
$pw = addslashes($_GET['pw']);
error_reporting(E_ALL);
ini_set("display_errors" ,1);

if(!empty($id) && !empty($pw)) {
	$c = "select id from user where id='{$id}'";
	$result = mysql_fetch_row(mysql_query($c));
	if($result[0] === NULL) {
		$q = "insert into user(id, pw) values('{$id}', '{$pw}')";
		$result = @mysql_fetch_array(mysql_query($q));
		echo '<script>alert("register success");</script>';
		echo "<script>location.href='./login.php';</script>";
	} else
		echo '<script>alert("id exist");</script>';
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<title><?php echo $title; ?></title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap.min.css">
<link href="css.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Main</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
		<?php
			if(!isset($_SESSION['id'])) {
				echo '<li><a href="login.php">LOGIN</a></li>';
				echo '<li><a href="register.php">REGISTER</a></li>';
			} else {
				echo '<li><a href="logout.php">LOGOUT</a></li>';
				echo '<li><a href="fileviewer.php">FILE</a></li>';
			}
		?>
        <li><a href="board.php">BOARD</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- First Container -->
<div class="container-fluid bg-1" id="index_container">
<div class="col-sm-4"></div>
<div class="col-sm-4">
	<form method="get">
	<h2>Create Account</h2>
	<div class="form-group">
		<label for="id">ID</label>
		<input type="text" class="form-control" id="id" name="id" autofocus>
	</div>
	<div class="form-group">
		<label for="password">Password</label>
		<input type="password" class="form-control" id="pw" name="pw">
	</div>
	<div class="form-group">
	<button type="submit" class="btn btn-default">Register</button>
	</div>
	</form>
</div>
<div class="col-sm-4"></div>
</div>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
  <p>Copyright (C) 2016 Hide All Rights Reserved</p>
</footer>

</body>
</html>
