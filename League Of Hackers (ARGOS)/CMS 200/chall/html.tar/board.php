<?php
session_start();
require_once("db.php");
require_once("login_chk.php");
require_once("func.php");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<title><?php echo $title; ?></title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap.min.css">
<link href="css.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
<script src="rotation.js"></script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Main</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
		<?php
			if(!isset($_SESSION['id'])) {
				echo '<li><a href="login.php">LOGIN</a></li>';
				echo '<li><a href="register.php">REGISTER</a></li>';
			} else {
				echo '<li><a href="logout.php">LOGOUT</a></li>';
				echo '<li><a href="fileviewer.php">FILE</a></li>';
			}
		?>
        <li><a href="board.php">BOARD</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- First Container -->
<div class="container-fluid bg-1 col-sm-8 col-sm-offset-2" id="index_container">
	<h2>Test Board</h2>
	<table class="table table-hover">
	<thead>
		<tr>
			<th>No</th>
			<th>Subject</th>
			<th>Writer</th>
		</tr>
	</thead>
	<tbody>
	<?php
		$q = $_GET['q'];
		if(isset($q)) {
			
		} else {
			$stmt = $conn->query("select no, subject, writer from board limit 10");
			while($row = $stmt->fetch()) {
				echo '<tr class="show_board" data-href="/read.php">';
				echo "<td>".$row['no']."</td>";
				echo "<td>".htmlspecialchars($row['subject'])."</td>";
				echo "<td>".htmlspecialchars($row['writer'])."</td>";
				echo "</tr>";
		}
		}
	?>
	</tbody>
	</table>
	<button type="button" class="btn btn-default" onclick="location.href='write.php'">Write</button>
</div>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
</footer>

</body>
</html>
