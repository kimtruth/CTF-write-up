<?php
session_start();
require_once("db.php");
require_once("login_chk.php");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<title>Intranet</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap.min.css">
<link href="css.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
<script src="rotation.js"></script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Main</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
		<?php
			if(!isset($_SESSION['id'])) {
				echo '<li><a href="login.php">LOGIN</a></li>';
				echo '<li><a href="register.php">REGISTER</a></li>';
			} else {
				echo '<li><a href="logout.php">LOGOUT</a></li>';
				echo '<li><a href="fileviewer.php">FILE</a></li>';
			}
		?>
        <li><a href="board.php">BOARD</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- First Container -->
<div class="container-fluid bg-1 col-sm-8 col-sm-offset-2" id="index_container">
	<form action="write_ok.php" method="post">
	<div class="form-group">
	<h2>Write</h2>
	<label for="subject">Subject</label>
	<input type="text" class="form-control" name="subject">
	</div>
	<div class="form-group">
	<label for="content">Content</label>
	<textarea class="form-control" name="content" row="5"></textarea>
	</div>
	<div class="form-group">
	<button type="button" class="btn btn-default" onclick="history.back();">Back</button>
	<button type="submit" class="btn btn-default">Write</button>
	</div>
	</form>
</div>

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
</footer>

</body>
</html>
